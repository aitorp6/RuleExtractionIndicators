#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.IO;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
#endregion

namespace NinjaTrader.NinjaScript.Indicators.RuleExtraction
{
    #region Core Calculations Class
    public static class RuleExtractionCalc
    {
        public static double Momentum(ISeries<double> close, int currentBar, int p)
        {
            if (currentBar < p) return double.NaN;
            double prev = close[p];
            if (prev == 0.0) return 100.0;
            return 100.0 * close[0] / prev;
        }

        public static double WPR(ISeries<double> high, ISeries<double> low, ISeries<double> close, int currentBar, int p)
        {
            if (currentBar < p - 1) return double.NaN;
            double mh = double.MinValue;
            double ml = double.MaxValue;
            for (int i = 0; i < p; i++)
            {
                if (high[i] > mh) mh = high[i];
                if (low[i] < ml) ml = low[i];
            }
            if (mh == ml) return -50.0;
            return -(mh - close[0]) * 100.0 / (mh - ml);
        }

        public static double Stoch(ISeries<double> high, ISeries<double> low, ISeries<double> close, int currentBar, int p, int suav)
        {
            if (currentBar < p + suav - 2) return double.NaN;
            double num = 0.0;
            double den = 0.0;
            for (int s = 0; s < suav; s++)
            {
                double barMh = double.MinValue;
                double barMl = double.MaxValue;
                for (int k = 0; k < p; k++)
                {
                    double hVal = high[s + k];
                    double lVal = low[s + k];
                    if (hVal > barMh) barMh = hVal;
                    if (lVal < barMl) barMl = lVal;
                }
                num += (close[s] - barMl);
                den += (barMh - barMl);
            }
            if (den == 0.0) return 100.0;
            return 100.0 * num / den;
        }

        public static double DeMarker(ISeries<double> high, ISeries<double> low, int currentBar, int p)
        {
            if (currentBar < p) return double.NaN;
            double smax = 0.0;
            double smin = 0.0;
            for (int i = 0; i < p; i++)
            {
                double dh = high[i] - high[i + 1];
                double dl = low[i] - low[i + 1];
                if (dh > 0) smax += dh;
                if (dl < 0) smin += -dl;
            }
            if (smax + smin == 0.0) return 0.5;
            return smax / (smax + smin);
        }

        public static double CloseSmaDev(ISeries<double> close, int currentBar, int p)
        {
            if (currentBar < p - 1) return double.NaN;
            double sum = 0.0;
            for (int i = 0; i < p; i++) sum += close[i];
            double sma = sum / p;
            if (sma == 0.0) return 0.0;
            return (close[0] - sma) / sma;
        }

        public static double AvIBS(ISeries<double> high, ISeries<double> low, ISeries<double> close, int currentBar, int p)
        {
            if (currentBar < p - 1) return double.NaN;
            double sumIbs = 0.0;
            for (int i = 0; i < p; i++)
            {
                double rng = high[i] - low[i];
                double ibs = (rng > 0) ? (close[i] - low[i]) / rng : 0.5;
                sumIbs += ibs;
            }
            return sumIbs / p;
        }

        public static double KER(ISeries<double> close, int currentBar, int p)
        {
            if (currentBar < p) return double.NaN;
            double direccion = Math.Abs(close[0] - close[p]);
            double vol = 0.0;
            for (int i = 0; i < p; i++)
            {
                vol += Math.Abs(close[i] - close[i + 1]);
            }
            if (vol > 0.0) return direccion / vol;
            return 0.0;
        }

        public static double HBM(ISeries<double> high, ISeries<double> close, int currentBar, int p)
        {
            if (currentBar < p) return double.NaN;
            double prevMax = double.MinValue;
            for (int i = 1; i <= p; i++)
            {
                if (high[i] > prevMax) prevMax = high[i];
            }
            return (high[0] - prevMax) / close[0];
        }

        public static double LBM(ISeries<double> low, ISeries<double> close, int currentBar, int p)
        {
            if (currentBar < p) return double.NaN;
            double prevMin = double.MaxValue;
            for (int i = 1; i <= p; i++)
            {
                if (low[i] < prevMin) prevMin = low[i];
            }
            return (low[0] - prevMin) / close[0];
        }

        public static double CCI(ISeries<double> high, ISeries<double> low, ISeries<double> close, int currentBar, int p)
        {
            if (currentBar < p - 1) return double.NaN;
            double sumTp = 0.0;
            for (int i = 0; i < p; i++)
            {
                sumTp += (high[i] + low[i] + close[i]) / 3.0;
            }
            double sma = sumTp / p;
            double sumMad = 0.0;
            for (int i = 0; i < p; i++)
            {
                double tp = (high[i] + low[i] + close[i]) / 3.0;
                sumMad += Math.Abs(tp - sma);
            }
            double mad = sumMad / p;
            double tp0 = (high[0] + low[0] + close[0]) / 3.0;
            if (mad == 0.0) return 0.0;
            return (tp0 - sma) / (0.015 * mad);
        }

        public static double RVI(ISeries<double> open, ISeries<double> high, ISeries<double> low, ISeries<double> close, int currentBar, int p)
        {
            if (currentBar < p + 2) return double.NaN;
            double sumUp = 0.0;
            double sumDn = 0.0;
            for (int i = 0; i < p; i++)
            {
                double co0 = close[i] - open[i];
                double co1 = close[i + 1] - open[i + 1];
                double co2 = close[i + 2] - open[i + 2];
                double co3 = close[i + 3] - open[i + 3];
                double triCo = co0 + 2.0 * co1 + 2.0 * co2 + co3;

                double hl0 = high[i] - low[i];
                double hl1 = high[i + 1] - low[i + 1];
                double hl2 = high[i + 2] - low[i + 2];
                double hl3 = high[i + 3] - low[i + 3];
                double triHl = hl0 + 2.0 * hl1 + 2.0 * hl2 + hl3;

                sumUp += triCo;
                sumDn += triHl;
            }
            if (sumDn != 0.0) return sumUp / sumDn;
            return sumUp;
        }

        public static void Aroon(ISeries<double> high, ISeries<double> low, int currentBar, int p, out double aroonUp, out double aroonDn)
        {
            if (currentBar < p)
            {
                aroonUp = double.NaN;
                aroonDn = double.NaN;
                return;
            }
            double maxVal = double.MinValue;
            double minVal = double.MaxValue;
            int desdeMax = 0;
            int desdeMin = 0;
            for (int i = 0; i <= p; i++)
            {
                if (high[i] > maxVal)
                {
                    maxVal = high[i];
                    desdeMax = i;
                }
                if (low[i] < minVal)
                {
                    minVal = low[i];
                    desdeMin = i;
                }
            }
            aroonUp = 100.0 * (p - desdeMax) / p;
            aroonDn = 100.0 * (p - desdeMin) / p;
        }
    }
    #endregion

    #region Individual NinjaScript Indicators

    public class RE_Momentum : Indicator
    {
        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Period", Order=1, GroupName="Parameters")]
        public int Period { get; set; }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "Momentum porcentual idéntico a Python indicators.py";
                Name = "RE_Momentum";
                Calculate = Calculate.OnBarClose;
                IsOverlay = false;
                Period = 14;
                AddPlot(Brushes.DodgerBlue, "Momentum");
            }
        }

        protected override void OnBarUpdate()
        {
            Value[0] = RuleExtractionCalc.Momentum(Close, CurrentBar, Period);
        }
    }

    public class RE_WPR : Indicator
    {
        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Period", Order=1, GroupName="Parameters")]
        public int Period { get; set; }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "Williams %R idéntico a Python indicators.py";
                Name = "RE_WPR";
                Calculate = Calculate.OnBarClose;
                IsOverlay = false;
                Period = 14;
                AddPlot(Brushes.Crimson, "WPR");
            }
        }

        protected override void OnBarUpdate()
        {
            Value[0] = RuleExtractionCalc.WPR(High, Low, Close, CurrentBar, Period);
        }
    }

    public class RE_Stoch : Indicator
    {
        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Period", Order=1, GroupName="Parameters")]
        public int Period { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Smoothing", Order=2, GroupName="Parameters")]
        public int Smoothing { get; set; }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "Estocástico idéntico a Python indicators.py";
                Name = "RE_Stoch";
                Calculate = Calculate.OnBarClose;
                IsOverlay = false;
                Period = 14;
                Smoothing = 3;
                AddPlot(Brushes.DeepSkyBlue, "Stoch");
            }
        }

        protected override void OnBarUpdate()
        {
            Value[0] = RuleExtractionCalc.Stoch(High, Low, Close, CurrentBar, Period, Smoothing);
        }
    }

    public class RE_DeMarker : Indicator
    {
        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Period", Order=1, GroupName="Parameters")]
        public int Period { get; set; }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "DeMarker idéntico a Python indicators.py";
                Name = "RE_DeMarker";
                Calculate = Calculate.OnBarClose;
                IsOverlay = false;
                Period = 14;
                AddPlot(Brushes.Orange, "DeMarker");
            }
        }

        protected override void OnBarUpdate()
        {
            Value[0] = RuleExtractionCalc.DeMarker(High, Low, CurrentBar, Period);
        }
    }

    public class RE_CloseSmaDev : Indicator
    {
        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Period", Order=1, GroupName="Parameters")]
        public int Period { get; set; }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "Close SMA Deviation idéntico a Python indicators.py";
                Name = "RE_CloseSmaDev";
                Calculate = Calculate.OnBarClose;
                IsOverlay = false;
                Period = 14;
                AddPlot(Brushes.SlateBlue, "CloseSmaDev");
            }
        }

        protected override void OnBarUpdate()
        {
            Value[0] = RuleExtractionCalc.CloseSmaDev(Close, CurrentBar, Period);
        }
    }

    public class RE_AvIBS : Indicator
    {
        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Period", Order=1, GroupName="Parameters")]
        public int Period { get; set; }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "Average IBS idéntico a Python indicators.py";
                Name = "RE_AvIBS";
                Calculate = Calculate.OnBarClose;
                IsOverlay = false;
                Period = 14;
                AddPlot(Brushes.ForestGreen, "AvIBS");
            }
        }

        protected override void OnBarUpdate()
        {
            Value[0] = RuleExtractionCalc.AvIBS(High, Low, Close, CurrentBar, Period);
        }
    }

    public class RE_KER : Indicator
    {
        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Period", Order=1, GroupName="Parameters")]
        public int Period { get; set; }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "Kaufman Efficiency Ratio (KER) idéntico a Python indicators.py";
                Name = "RE_KER";
                Calculate = Calculate.OnBarClose;
                IsOverlay = false;
                Period = 14;
                AddPlot(Brushes.MediumSeaGreen, "KER");
            }
        }

        protected override void OnBarUpdate()
        {
            Value[0] = RuleExtractionCalc.KER(Close, CurrentBar, Period);
        }
    }

    public class RE_HBM : Indicator
    {
        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Period", Order=1, GroupName="Parameters")]
        public int Period { get; set; }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "High Beyond Max (HBM) idéntico a Python indicators.py";
                Name = "RE_HBM";
                Calculate = Calculate.OnBarClose;
                IsOverlay = false;
                Period = 14;
                AddPlot(Brushes.Goldenrod, "HBM");
            }
        }

        protected override void OnBarUpdate()
        {
            Value[0] = RuleExtractionCalc.HBM(High, Close, CurrentBar, Period);
        }
    }

    public class RE_LBM : Indicator
    {
        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Period", Order=1, GroupName="Parameters")]
        public int Period { get; set; }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "Low Below Min (LBM) idéntico a Python indicators.py";
                Name = "RE_LBM";
                Calculate = Calculate.OnBarClose;
                IsOverlay = false;
                Period = 14;
                AddPlot(Brushes.DarkOrange, "LBM");
            }
        }

        protected override void OnBarUpdate()
        {
            Value[0] = RuleExtractionCalc.LBM(Low, Close, CurrentBar, Period);
        }
    }

    public class RE_RSI : Indicator
    {
        private Series<double> posSeries;
        private Series<double> negSeries;

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Period", Order=1, GroupName="Parameters")]
        public int Period { get; set; }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "RSI Wilder con semilla SMA idéntico a Python indicators.py";
                Name = "RE_RSI";
                Calculate = Calculate.OnBarClose;
                IsOverlay = false;
                Period = 14;
                AddPlot(Brushes.SteelBlue, "RSI");
            }
            else if (State == State.DataLoaded)
            {
                posSeries = new Series<double>(this);
                negSeries = new Series<double>(this);
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < Period)
            {
                posSeries[0] = 0;
                negSeries[0] = 0;
                Value[0] = double.NaN;
                return;
            }

            if (CurrentBar == Period)
            {
                double sumG = 0;
                double sumL = 0;
                for (int i = 0; i < Period; i++)
                {
                    double d = Close[i] - Close[i + 1];
                    if (d > 0) sumG += d;
                    else if (d < 0) sumL += -d;
                }
                posSeries[0] = sumG / Period;
                negSeries[0] = sumL / Period;
            }
            else
            {
                double d = Close[0] - Close[1];
                double g = d > 0 ? d : 0.0;
                double l = d < 0 ? -d : 0.0;
                posSeries[0] = (posSeries[1] * (Period - 1) + g) / Period;
                negSeries[0] = (negSeries[1] * (Period - 1) + l) / Period;
            }

            double pos = posSeries[0];
            double neg = negSeries[0];
            if (neg != 0.0)
                Value[0] = 100.0 - 100.0 / (1.0 + pos / neg);
            else
                Value[0] = pos != 0.0 ? 100.0 : 50.0;
        }
    }

    public class RE_TRIX : Indicator
    {
        private Series<double> e1Series;
        private Series<double> e2Series;
        private Series<double> e3Series;

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Period", Order=1, GroupName="Parameters")]
        public int Period { get; set; }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "TRIX triple EMA sembrada idéntico a Python indicators.py";
                Name = "RE_TRIX";
                Calculate = Calculate.OnBarClose;
                IsOverlay = false;
                Period = 14;
                AddPlot(Brushes.MediumVioletRed, "TRIX");
            }
            else if (State == State.DataLoaded)
            {
                e1Series = new Series<double>(this);
                e2Series = new Series<double>(this);
                e3Series = new Series<double>(this);
            }
        }

        protected override void OnBarUpdate()
        {
            double a = 2.0 / (Period + 1.0);

            // EMA 1
            if (CurrentBar < Period - 1)
            {
                e1Series[0] = double.NaN;
            }
            else if (CurrentBar == Period - 1)
            {
                double s = 0;
                for (int i = 0; i < Period; i++) s += Close[i];
                e1Series[0] = s / Period;
            }
            else
            {
                e1Series[0] = e1Series[1] + a * (Close[0] - e1Series[1]);
            }

            // EMA 2
            if (CurrentBar < 2 * Period - 2)
            {
                e2Series[0] = double.NaN;
            }
            else if (CurrentBar == 2 * Period - 2)
            {
                double s = 0;
                for (int i = 0; i < Period; i++) s += e1Series[i];
                e2Series[0] = s / Period;
            }
            else
            {
                e2Series[0] = e2Series[1] + a * (e1Series[0] - e2Series[1]);
            }

            // EMA 3
            if (CurrentBar < 3 * Period - 3)
            {
                e3Series[0] = double.NaN;
            }
            else if (CurrentBar == 3 * Period - 3)
            {
                double s = 0;
                for (int i = 0; i < Period; i++) s += e2Series[i];
                e3Series[0] = s / Period;
            }
            else
            {
                e3Series[0] = e3Series[1] + a * (e2Series[0] - e3Series[1]);
            }

            // TRIX Rate of Change
            if (CurrentBar < 3 * Period - 2 || double.IsNaN(e3Series[0]) || double.IsNaN(e3Series[1]))
            {
                Value[0] = double.NaN;
            }
            else
            {
                double prev = e3Series[1];
                Value[0] = prev != 0.0 ? (e3Series[0] - prev) / prev : 0.0;
            }
        }
    }

    public class RE_DIWilder : Indicator
    {
        private Series<double> sTSeries;
        private Series<double> sPSeries;
        private Series<double> sMSeries;

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Period", Order=1, GroupName="Parameters")]
        public int Period { get; set; }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "+DI y -DI Wilder idénticos a Python indicators.py";
                Name = "RE_DIWilder";
                Calculate = Calculate.OnBarClose;
                IsOverlay = false;
                Period = 14;
                AddPlot(Brushes.Green, "PDI");
                AddPlot(Brushes.Red, "MDI");
            }
            else if (State == State.DataLoaded)
            {
                sTSeries = new Series<double>(this);
                sPSeries = new Series<double>(this);
                sMSeries = new Series<double>(this);
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < Period)
            {
                sTSeries[0] = 0;
                sPSeries[0] = 0;
                sMSeries[0] = 0;
                Values[0][0] = double.NaN;
                Values[1][0] = double.NaN;
                return;
            }

            if (CurrentBar == Period)
            {
                double st = 0, sp = 0, sm = 0;
                for (int i = 0; i < Period; i++)
                {
                    double tr = Math.Max(High[i], Close[i + 1]) - Math.Min(Low[i], Close[i + 1]);
                    double up = High[i] - High[i + 1];
                    double dn = Low[i + 1] - Low[i];
                    double pdm = (up > dn && up > 0) ? up : 0.0;
                    double mdm = (dn > up && dn > 0) ? dn : 0.0;
                    st += tr;
                    sp += pdm;
                    sm += mdm;
                }
                sTSeries[0] = st;
                sPSeries[0] = sp;
                sMSeries[0] = sm;
            }
            else
            {
                double tr = Math.Max(High[0], Close[1]) - Math.Min(Low[0], Close[1]);
                double up = High[0] - High[1];
                double dn = Low[1] - Low[0];
                double pdm = (up > dn && up > 0) ? up : 0.0;
                double mdm = (dn > up && dn > 0) ? dn : 0.0;

                sTSeries[0] = sTSeries[1] - sTSeries[1] / Period + tr;
                sPSeries[0] = sPSeries[1] - sPSeries[1] / Period + pdm;
                sMSeries[0] = sMSeries[1] - sMSeries[1] / Period + mdm;
            }

            double sT = sTSeries[0];
            double sP = sPSeries[0];
            double sM = sMSeries[0];

            Values[0][0] = sT > 0 ? 100.0 * sP / sT : 0.0;
            Values[1][0] = sT > 0 ? 100.0 * sM / sT : 0.0;
        }
    }

    public class RE_CCI : Indicator
    {
        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Period", Order=1, GroupName="Parameters")]
        public int Period { get; set; }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "CCI idéntico a Python indicators.py";
                Name = "RE_CCI";
                Calculate = Calculate.OnBarClose;
                IsOverlay = false;
                Period = 14;
                AddPlot(Brushes.DarkCyan, "CCI");
            }
        }

        protected override void OnBarUpdate()
        {
            Value[0] = RuleExtractionCalc.CCI(High, Low, Close, CurrentBar, Period);
        }
    }

    public class RE_RVI : Indicator
    {
        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Period", Order=1, GroupName="Parameters")]
        public int Period { get; set; }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "RVI con filtro 1,2,2,1 idéntico a Python indicators.py";
                Name = "RE_RVI";
                Calculate = Calculate.OnBarClose;
                IsOverlay = false;
                Period = 14;
                AddPlot(Brushes.MediumSeaGreen, "RVI");
            }
        }

        protected override void OnBarUpdate()
        {
            Value[0] = RuleExtractionCalc.RVI(Open, High, Low, Close, CurrentBar, Period);
        }
    }

    public class RE_Aroon : Indicator
    {
        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Period", Order=1, GroupName="Parameters")]
        public int Period { get; set; }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "Aroon Up / Down idéntico a Python indicators.py";
                Name = "RE_Aroon";
                Calculate = Calculate.OnBarClose;
                IsOverlay = false;
                Period = 14;
                AddPlot(Brushes.SeaGreen, "AroonUp");
                AddPlot(Brushes.IndianRed, "AroonDown");
            }
        }

        protected override void OnBarUpdate()
        {
            double up, dn;
            RuleExtractionCalc.Aroon(High, Low, CurrentBar, Period, out up, out dn);
            Values[0][0] = up;
            Values[1][0] = dn;
        }
    }

    #endregion
}
